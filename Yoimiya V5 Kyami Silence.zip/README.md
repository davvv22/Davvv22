//SC BY DINZID VyL
// © BY DinzID Vyl 2022 - 2025
//JANGAN HAPUS CREDITS!! HAPUS? = GW ENC SEMUA!! 

# YOIMIYA - MD // DINZID VyL  
Yoimiya - mD adalah bot WhatsApp berbasis **Baileys** yang memiliki berbagai fitur keren buat memudahkan hidup lo!  

## 🔹 **Group Room Chat Yoimiya:** [Klik Disini](https://chat.whatsapp.com/Gv1gsvCBiukEBpaRQ4qDSO)  
//JAN DIUBAH

## Fitur Utama  

✅ **𝙂𝙍𝙊𝙐𝙋 𝙈𝙀𝙉𝙐** (Welcome, Anti-link, Auto Close Group)  
✅ **𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 𝙈𝙀𝙉𝙐** (YouTube, TikTok DLL)  
✅ **𝙎𝙏𝙄𝘾𝙆𝙀𝙍 & 𝙈𝙀𝘿𝙄𝘼** (Convert ke stiker, brat image/video)  
✅ **𝙁𝙐𝙉 𝙈𝙀𝙉𝙐 & 𝙍𝙋𝙂** (KERJA, CRAFT, BANKCEK DLL)  
✅ **𝙄𝙎𝙇𝘼𝙈𝙄 𝙈𝙀𝙉𝙐** (PENGINGAT ADZAN, PENGINGAT SHOLAT, AUTO ADZAN DLL)
#WAJIB 𝐁𝐀𝐂𝐀 !!
Edit file `settings.js` sebelum menjalankan bot:  

```---    settings.js
global.ownername = "DinzID VyL"
global.botname = "Yoimiya - MD"
global.ownernumber = "6283182739135"
global.idSaluran = "120363283540203585@newsletter"
```  

## 𝙂𝘼𝘽𝙐𝙉𝙂 𝙆𝙊𝙈𝙐𝙉𝙄𝙏𝘼𝙎 𝘿𝙄𝙉𝙕𝙄𝘿 𝘾𝙃𝙓

🔹 **𝙂𝙍𝙊𝙐𝙋 𝘾𝙃𝘼𝙏** [Klik Disini](https://flowfalcon.xyz/group/)  
🔹 **𝘾𝙃𝘼𝙉𝙉𝙀𝙇 𝙊𝙍𝙄 𝙔𝙊𝙄𝙈𝙄𝙔𝘼** [Klik Disini](https://flowfalcon.xyz/channel/)  
#DILARANG HAPUS CREDITS 
#footer '© DinzID VyL | Yoimiya - MD'