const _0x789bb1 = _0x27b1;
(function (_0x5a12cd, _0x105319) {
    const _0x1e5046 = _0x27b1, _0x3f67a7 = _0x5a12cd();
    while (!![]) {
        try {
            const _0xe94722 = parseInt(_0x1e5046(0x1f7)) / (0x3 * 0x755 + 0x133 * -0x1d + 0xcc9) * (-parseInt(_0x1e5046(0x222)) / (-0x67 * -0x1c + -0x1379 * -0x1 + 0x1 * -0x1ebb)) + -parseInt(_0x1e5046(0x209)) / (-0xdf * 0x7 + -0x180e * -0x1 + -0x11f2) + parseInt(_0x1e5046(0x229)) / (0xc69 * -0x3 + 0x1790 + 0x1f * 0x71) + parseInt(_0x1e5046(0x214)) / (0x1655 * -0x1 + 0x88 * -0x3 + 0x17f2) * (-parseInt(_0x1e5046(0x204)) / (0x2196 + 0xb * -0x65 + -0x1d39)) + -parseInt(_0x1e5046(0x213)) / (-0x1bff + 0x18e2 + 0x2 * 0x192) * (-parseInt(_0x1e5046(0x211)) / (0x459 + 0xb85 + -0xfd6)) + parseInt(_0x1e5046(0x20e)) / (-0x146f * 0x1 + -0x1f38 + 0x33b0) + -parseInt(_0x1e5046(0x233)) / (-0x2138 + 0x2250 + -0x10e);
            if (_0xe94722 === _0x105319)
                break;
            else
                _0x3f67a7['push'](_0x3f67a7['shift']());
        } catch (_0x22ec13) {
            _0x3f67a7['push'](_0x3f67a7['shift']());
        }
    }
}(_0x39fb, 0x50ba * 0x1f + 0x1aef61 * 0x1 + -0x11e * 0x1352), require(_0x789bb1(0x22f)));
const {modul} = require(_0x789bb1(0x21b)), moment = require(_0x789bb1(0x200) + _0x789bb1(0x218)), {baileys, boom, chalk, fs, figlet, FileType, path, pino, process, PhoneNumber, axios, yargs, _} = modul, {Boom} = boom, {
        default: XeonBotIncConnect,
        BufferJSON,
        processedMessages,
        PHONENUMBER_MCC,
        initInMemoryKeyStore,
        DisconnectReason,
        AnyMessageContent,
        makeInMemoryStore,
        useMultiFileAuthState,
        delay,
        fetchLatestBaileysVersion,
        generateForwardMessageContent,
        prepareWAMessageMedia,
        generateWAMessageFromContent,
        generateMessageID,
        downloadContentFromMessage,
        jidDecode,
        makeCacheableSignalKeyStore,
        getAggregateVotesInPollMessage,
        proto
    } = require(_0x789bb1(0x1f4) + _0x789bb1(0x202) + _0x789bb1(0x212)), cfonts = require(_0x789bb1(0x21d)), {color, bgcolor} = require(_0x789bb1(0x20f) + 'r'), {TelegraPh} = require(_0x789bb1(0x1fb) + _0x789bb1(0x22b)), NodeCache = require(_0x789bb1(0x21c)), canvafy = require(_0x789bb1(0x228)), {parsePhoneNumber} = require(_0x789bb1(0x221) + _0x789bb1(0x22a));
let _welcome = JSON[_0x789bb1(0x21f)](fs[_0x789bb1(0x216) + 'nc'](_0x789bb1(0x230) + _0x789bb1(0x1fa) + _0x789bb1(0x22c))), _left = JSON[_0x789bb1(0x21f)](fs[_0x789bb1(0x216) + 'nc'](_0x789bb1(0x230) + _0x789bb1(0x215)));
function _0x27b1(_0x257b97, _0x379817) {
    const _0x3c8e52 = _0x39fb();
    return _0x27b1 = function (_0x2b8f3d, _0x597d4f) {
        _0x2b8f3d = _0x2b8f3d - (-0x1 * -0x2459 + -0x1702 + -0xb64);
        let _0x2dfb9e = _0x3c8e52[_0x2b8f3d];
        return _0x2dfb9e;
    }, _0x27b1(_0x257b97, _0x379817);
}
const makeWASocket = require(_0x789bb1(0x1f4) + _0x789bb1(0x202) + _0x789bb1(0x212))[_0x789bb1(0x1f8)], Pino = require(_0x789bb1(0x1f5)), readline = require(_0x789bb1(0x20b)), colors = require(_0x789bb1(0x205)), {start} = require(_0x789bb1(0x1f9) + _0x789bb1(0x1fe)), {uncache, nocache} = require(_0x789bb1(0x225) + 'er'), {imageToWebp, videoToWebp, writeExifImg, writeExifVid} = require(_0x789bb1(0x21e)), {smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep, reSize} = require(_0x789bb1(0x223) + 'nc'), prefix = '.';
let phoneNumber = _0x789bb1(0x203) + '13';
global['db'] = JSON[_0x789bb1(0x21f)](fs[_0x789bb1(0x216) + 'nc'](_0x789bb1(0x230) + _0x789bb1(0x21a) + _0x789bb1(0x22d)));
if (global['db'])
    global['db'] = {
        'sticker': {},
        'database': {},
        'groups': {},
        'game': {},
        'others': {},
        'users': {},
        'chats': {},
        'settings': {},
        ...global['db'] || {}
    };
const pairingCode = !!phoneNumber || process[_0x789bb1(0x20a)][_0x789bb1(0x1ff)](_0x789bb1(0x1f3) + _0x789bb1(0x217)), useMobile = process[_0x789bb1(0x20a)][_0x789bb1(0x1ff)](_0x789bb1(0x206)), owner = JSON[_0x789bb1(0x21f)](fs[_0x789bb1(0x216) + 'nc'](_0x789bb1(0x230) + _0x789bb1(0x1fc) + 'n')), store = makeInMemoryStore({
        'logger': pino()[_0x789bb1(0x22e)]({
            'level': _0x789bb1(0x1fd),
            'stream': _0x789bb1(0x201)
        })
    }), rl = readline[_0x789bb1(0x227) + _0x789bb1(0x219)]({
        'input': process[_0x789bb1(0x226)],
        'output': process[_0x789bb1(0x207)]
    }), question = _0x597d4f => new Promise(_0x2dfb9e => rl[_0x789bb1(0x1f6)](_0x597d4f, _0x2dfb9e));
require(_0x789bb1(0x224) + 's'), nocache(_0x789bb1(0x20c) + 'js', _0x17dcd4 => console[_0x789bb1(0x231)](color(_0x789bb1(0x208), _0x789bb1(0x220)), color('\x27' + _0x17dcd4 + '\x27', _0x789bb1(0x220)), _0x789bb1(0x20d))), require(_0x789bb1(0x210)), nocache(_0x789bb1(0x232) + 's', _0x1925ac => console[_0x789bb1(0x231)](color(_0x789bb1(0x208), _0x789bb1(0x220)), color('\x27' + _0x1925ac + '\x27', _0x789bb1(0x220)), _0x789bb1(0x20d)));
function _0x39fb() {
    const _0x17e8ae = [
        '../DinzID.',
        'Updated',
        '13917834qsYsja',
        './lib/colo',
        './index.js',
        '2168RqUAAf',
        'eys',
        '36617qXzxrw',
        '5wIfywL',
        '/left.json',
        'readFileSy',
        'code',
        'ezone',
        'rface',
        '/database.',
        './module',
        'node-cache',
        'cfonts',
        './lib/exif',
        'parse',
        'green',
        'libphonenu',
        '967976TPMwUN',
        './lib/myfu',
        './DinzID.j',
        './lib/load',
        'stdin',
        'createInte',
        'canvafy',
        '5432152OgNAJU',
        'mber-js',
        'ader',
        'son',
        'json',
        'child',
        './settings',
        './database',
        'log',
        '../index.j',
        '4748900RaxSCW',
        '--pairing-',
        '@whiskeyso',
        'pino',
        'question',
        '2tQlEbp',
        'default',
        './lib/spin',
        '/welcome.j',
        './lib/uplo',
        '/owner.jso',
        'silent',
        'ner',
        'includes',
        'moment-tim',
        'store',
        'ckets/bail',
        '9169091372',
        '1619814ZRuSyO',
        'colors',
        '--mobile',
        'stdout',
        '[\x20CHANGE\x20]',
        '4853769MTJXrG',
        'argv',
        'readline'
    ];
    _0x39fb = function () {
        return _0x17e8ae;
    };
    return _0x39fb();
}

async function DinzBotzInd() {
	const {  saveCreds, state } = await useMultiFileAuthState(`./${sessionName}`)
	const msgRetryCounterCache = new NodeCache()
    	const DinzBotz = XeonBotIncConnect({
        logger: pino({ level: 'silent' }),
        printQRInTerminal: !pairingCode, // popping up QR in terminal log
      mobile: useMobile, // mobile api (prone to bans)
     auth: {
         creds: state.creds,
         keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: "fatal" }).child({ level: "fatal" })),
      },
      browser: [ 'Mac OS', 'Safari', '10.15.7' ], // for this issues https://github.com/WhiskeySockets/Baileys/issues/328
      patchMessageBeforeSending: (message) => {
            const requiresPatch = !!(
                message.buttonsMessage ||
                message.templateMessage ||
                message.listMessage
            );
            if (requiresPatch) {
                message = {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {},
                            },
                            ...message,
                        },
                    },
                };
            }
            return message;
        },
      auth: {
         creds: state.creds,
         keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
      },
connectTimeoutMs: 60000,
defaultQueryTimeoutMs: 0,
keepAliveIntervalMs: 10000,
emitOwnEvents: true,
fireInitQueries: true,
generateHighQualityLinkPreview: true,
syncFullHistory: true,
markOnlineOnConnect: true,
      getMessage: async (key) => {
            if (store) {
                const msg = await store.loadMessage(key.remoteJid, key.id)
                return msg.message || undefined
            }
            return {
                conversation: "Yoimiya Disini!"
            }
        },
      msgRetryCounterCache, // Resolve waiting messages
      defaultQueryTimeoutMs: undefined, // for this issues https://github.com/WhiskeySockets/Baileys/issues/276
   })
const _0xde3dbe = _0x37ea;
function _0x5808() {
    const _0x1b5b78 = [
        '1203633667',
        '1203634156',
        'ctsaC',
        'pyEwO',
        'RILFU',
        'shyde',
        'qkfxU',
        '90950043@n',
        'statusCode',
        '03332542@n',
        '236541FHtyuH',
        'Lost',
        'Yellow',
        'transparen',
        'HNQmt',
        '03332542@n',
        'e\x20Session\x20',
        'OjeRZ',
        '90950043@n',
        'ged\x20Out,\x20P',
        'loggedOut',
        'close',
        '1203634156',
        'Closed',
        'sXDYJ',
        'ewsletter',
        'YOIMIYA',
        'uired',
        'aqua',
        'ew\x20Session',
        'newsletter',
        'ZXgpI',
        'ndingNotif',
        'IRING\x20LU\x20]',
        '1203633667',
        '03332542@n',
        'open',
        'GIqNz',
        'ing...',
        'JNnwb',
        'false',
        '\x20:\x20',
        'sconnectRe',
        'bind',
        'badSession',
        '446108kVUPXe',
        'Replaced',
        'CaWug',
        'ications',
        'timedOut',
        'eyIdV',
        'onnection.',
        '.update',
        'koLVU',
        'connection',
        '90950043@n',
        'g....',
        'ease\x20Delet',
        'econnectin',
        '\x0a\x0aMenghubu',
        'ngkan...',
        'HQMab',
        'left',
        'ktif\x20Awali',
        'oGfoE',
        '\x20Again\x20And',
        'rst',
        '198620GjjEJK',
        '438QiKcsl',
        'error',
        '\x20TimedOut,',
        '1203634156',
        'connecting',
        '\x20Run.',
        'jLBfX',
        '14810xtmSyG',
        'update\x20',
        'quired,\x20Re',
        'OKdpU',
        'n\x20File,\x20Pl',
        'AGYVH',
        '1203633667',
        'VMkuP',
        '4588440YOWklW',
        '03332542@n',
        'mer\x20Yang\x20A',
        'Follow',
        'fWdsC',
        'Connection',
        'lease\x20Scan',
        '18dOjPiJ',
        '48274213@n',
        'Masukan\x20No',
        'IkvCD',
        'OCtIb',
        'guaKm',
        '304qnacWw',
        'e\x20Current\x20',
        'Error\x20in\x20C',
        'Unknown\x20Di',
        '\x0a[\x20CODE\x20PA',
        'VogwE',
        '\x20Dengan\x2062',
        'xUEDh',
        'ZLGgg',
        '90950043@n',
        'creds',
        'Bad\x20Sessio',
        '1203634156',
        'ypJWC',
        'ason:\x20',
        '1203633667',
        'true',
        'receivedPe',
        'EDjSz',
        'WzOAH',
        'Device\x20Log',
        'Session\x20Fi',
        'Pqluj',
        'authState',
        'yOjwU',
        'registered',
        'ieawY',
        'say',
        '1203634156',
        '03332542@n',
        '\x20Server,\x20r',
        'cvjpz',
        '1203634156',
        'MAlel',
        'FoKpr',
        'vFVCo',
        'requestPai',
        'lNnvz',
        'lease\x20Clos',
        'ringCode',
        'wTFas',
        'starting..',
        'keyword',
        '10003dWTHTU',
        'hypyz',
        'GTpeh',
        '\x20Lost\x20from',
        'gain',
        '\x20Replaced,',
        'block',
        'TakrC',
        '\x20Recode\x20:\x0a',
        '\x20Reconnect',
        'restartReq',
        '\x20Another\x20N',
        'WhiteBrigh',
        'output',
        '\x20Opened,\x20P',
        'Restart\x20Re',
        'and\x20Scan\x20A',
        'IyYCF',
        'yellow',
        '\x20closed,\x20r',
        '15189uGdmwX',
        'g...',
        'YOIMIYAA',
        'log'
    ];
    _0x5808 = function () {
        return _0x1b5b78;
    };
    return _0x5808();
}
function _0x37ea(_0x29e849, _0x3c8872) {
    const _0x274fab = _0x5808();
    return _0x37ea = function (_0xd314fe, _0x57fadc) {
        _0xd314fe = _0xd314fe - (0x3 * 0x695 + -0x1c55 + 0x986);
        let _0x57ea0c = _0x274fab[_0xd314fe];
        return _0x57ea0c;
    }, _0x37ea(_0x29e849, _0x3c8872);
}
(function (_0x5044fd, _0x2933d9) {
    const _0x41fa8f = _0x37ea, _0x28c34c = _0x5044fd();
    while (!![]) {
        try {
            const _0x35bf7a = -parseInt(_0x41fa8f(0x15f)) / (-0x1338 + -0x30 * 0xce + -0xfb * -0x3b) + -parseInt(_0x41fa8f(0x182)) / (-0xdbc + -0x1 * 0x202f + 0x2ded) + parseInt(_0x41fa8f(0x151)) / (0x21c2 + 0x19ae + -0x3b6d) + -parseInt(_0x41fa8f(0xf5)) / (-0x2f * -0xc2 + 0x892 + -0x4 * 0xb0b) + parseInt(_0x41fa8f(0xfd)) / (-0x35 * 0x2d + -0x1a0d + 0x1 * 0x2363) * (-parseInt(_0x41fa8f(0xf6)) / (0x679 + -0x301 * -0xc + -0x2a7f)) + parseInt(_0x41fa8f(0x13d)) / (0x270d + -0x1e91 + -0x875) * (-parseInt(_0x41fa8f(0x112)) / (0xfbb + -0xa94 + -0x51f)) + -parseInt(_0x41fa8f(0x10c)) / (-0x17a7 + -0x95d + 0x210d) * (-parseInt(_0x41fa8f(0x105)) / (0x1667 + 0x1127 + 0x9e1 * -0x4));
            if (_0x35bf7a === _0x2933d9)
                break;
            else
                _0x28c34c['push'](_0x28c34c['shift']());
        } catch (_0x3fe3c2) {
            _0x28c34c['push'](_0x28c34c['shift']());
        }
    }
}(_0x5808, 0xd9a8 + 0x147e1 + 0xcf4));
if (!DinzBotz[_0xde3dbe(0x129)][_0xde3dbe(0x11c)][_0xde3dbe(0x12b)]) {
    const phoneNumber = await question(_0xde3dbe(0x10e) + _0xde3dbe(0x107) + _0xde3dbe(0xf1) + _0xde3dbe(0x118) + _0xde3dbe(0x145));
    let custom = _0xde3dbe(0x153);
    const code = await DinzBotz[_0xde3dbe(0x136) + _0xde3dbe(0x139)](phoneNumber, custom);
    console[_0xde3dbe(0x154)](chalk[_0xde3dbe(0x13c)](_0xde3dbe(0x171))(_0xde3dbe(0x116) + _0xde3dbe(0x176) + _0xde3dbe(0x17e) + code));
}
store[_0xde3dbe(0x180)](DinzBotz['ev']), DinzBotz['ev']['on'](_0xde3dbe(0x18b) + _0xde3dbe(0x189), async _0x2a93f7 => {
    const _0x34be67 = _0xde3dbe, _0x29d50c = {
            'eyIdV': function (_0x159161, _0x4bc790) {
                return _0x159161 === _0x4bc790;
            },
            'GIqNz': _0x34be67(0x16a),
            'MAlel': function (_0x1e28b5, _0x184d58) {
                return _0x1e28b5 === _0x184d58;
            },
            'JNnwb': function (_0xa8ae7b) {
                return _0xa8ae7b();
            },
            'AGYVH': function (_0x3c5e3a, _0xe359aa) {
                return _0x3c5e3a === _0xe359aa;
            },
            'ypJWC': _0x34be67(0x10a) + _0x34be67(0x150) + _0x34be67(0x18f) + _0x34be67(0x18d),
            'fWdsC': function (_0x54e83e) {
                return _0x54e83e();
            },
            'ZLGgg': _0x34be67(0x10a) + _0x34be67(0x140) + _0x34be67(0x130) + _0x34be67(0x18f) + _0x34be67(0x152),
            'oGfoE': function (_0x596819) {
                return _0x596819();
            },
            'CaWug': _0x34be67(0x10a) + _0x34be67(0x142) + _0x34be67(0x148) + _0x34be67(0x172) + _0x34be67(0x14b) + _0x34be67(0x138) + _0x34be67(0x113) + _0x34be67(0x127) + _0x34be67(0xf4),
            'yOjwU': function (_0x1be2a3) {
                return _0x1be2a3();
            },
            'jLBfX': function (_0x3cf9b9) {
                return _0x3cf9b9();
            },
            'IkvCD': _0x34be67(0x14c) + _0x34be67(0xff) + _0x34be67(0x13b) + '.',
            'EDjSz': _0x34be67(0x10a) + _0x34be67(0xf8) + _0x34be67(0x146) + _0x34be67(0x17b),
            'wTFas': function (_0x4f8514) {
                return _0x4f8514();
            },
            'pyEwO': function (_0x1e2801, _0x401fd8) {
                return _0x1e2801 == _0x401fd8;
            },
            'HNQmt': _0x34be67(0xfa),
            'guaKm': _0x34be67(0x17d),
            'ieawY': function (_0x47b396, _0x50e6d7, _0x427d8a) {
                return _0x47b396(_0x50e6d7, _0x427d8a);
            },
            'OCtIb': _0x34be67(0x14f),
            'WzOAH': function (_0xd8e568, _0x427867) {
                return _0xd8e568 == _0x427867;
            },
            'GTpeh': _0x34be67(0x179),
            'shyde': _0x34be67(0x122),
            'Pqluj': _0x34be67(0x12e) + _0x34be67(0x167) + _0x34be67(0x16e),
            'ctsaC': _0x34be67(0x11e) + _0x34be67(0x106) + _0x34be67(0x16e),
            'ZXgpI': _0x34be67(0x121) + _0x34be67(0x178) + _0x34be67(0x16e),
            'sXDYJ': _0x34be67(0x132) + _0x34be67(0x15e) + _0x34be67(0x16e),
            'FoKpr': _0x34be67(0x156) + _0x34be67(0x12f) + _0x34be67(0x16e),
            'OjeRZ': _0x34be67(0x177) + _0x34be67(0x10d) + _0x34be67(0x16e),
            'koLVU': _0x34be67(0x103) + _0x34be67(0x164) + _0x34be67(0x16e),
            'OKdpU': _0x34be67(0x16b) + _0x34be67(0x11b) + _0x34be67(0x16e),
            'IyYCF': _0x34be67(0x155) + _0x34be67(0x18c) + _0x34be67(0x16e),
            'lNnvz': _0x34be67(0xf9) + _0x34be67(0x15c) + _0x34be67(0x16e),
            'cvjpz': function (_0x25211d, _0xcba231) {
                return _0x25211d(_0xcba231);
            },
            'hypyz': _0x34be67(0x16f),
            'TakrC': _0x34be67(0x143),
            'RILFU': _0x34be67(0xf0),
            'qkfxU': _0x34be67(0x161),
            'xUEDh': _0x34be67(0x149) + 't',
            'HQMab': _0x34be67(0x162) + 't',
            'VMkuP': function (_0x7d6175, _0x2a0813) {
                return _0x7d6175 + _0x2a0813;
            },
            'VogwE': _0x34be67(0x114) + _0x34be67(0x188) + _0x34be67(0xfe),
            'vFVCo': function (_0x302f0a) {
                return _0x302f0a();
            }
        }, {
            connection: _0x2a59cb,
            lastDisconnect: _0x3309cc
        } = _0x2a93f7;
    try {
        if (_0x29d50c[_0x34be67(0x187)](_0x2a59cb, _0x29d50c[_0x34be67(0x17a)])) {
            let _0x5bb196 = new Boom(_0x3309cc?.[_0x34be67(0xf7)])?.[_0x34be67(0x14a)][_0x34be67(0x15d)];
            if (_0x29d50c[_0x34be67(0x133)](_0x5bb196, DisconnectReason[_0x34be67(0x181)]))
                console[_0x34be67(0x154)](_0x34be67(0x11d) + _0x34be67(0x101) + _0x34be67(0x18e) + _0x34be67(0x165) + _0x34be67(0x14d) + _0x34be67(0x141)), _0x29d50c[_0x34be67(0x17c)](DinzBotzInd);
            else {
                if (_0x29d50c[_0x34be67(0x102)](_0x5bb196, DisconnectReason[_0x34be67(0x18b) + _0x34be67(0x16c)]))
                    console[_0x34be67(0x154)](_0x29d50c[_0x34be67(0x11f)]), _0x29d50c[_0x34be67(0x109)](DinzBotzInd);
                else {
                    if (_0x29d50c[_0x34be67(0x133)](_0x5bb196, DisconnectReason[_0x34be67(0x18b) + _0x34be67(0x160)]))
                        console[_0x34be67(0x154)](_0x29d50c[_0x34be67(0x11a)]), _0x29d50c[_0x34be67(0xf2)](DinzBotzInd);
                    else {
                        if (_0x29d50c[_0x34be67(0x102)](_0x5bb196, DisconnectReason[_0x34be67(0x18b) + _0x34be67(0x183)]))
                            console[_0x34be67(0x154)](_0x29d50c[_0x34be67(0x184)]), _0x29d50c[_0x34be67(0x12a)](DinzBotzInd);
                        else {
                            if (_0x29d50c[_0x34be67(0x187)](_0x5bb196, DisconnectReason[_0x34be67(0x169)]))
                                console[_0x34be67(0x154)](_0x34be67(0x126) + _0x34be67(0x168) + _0x34be67(0x10b) + _0x34be67(0xf3) + _0x34be67(0xfb)), _0x29d50c[_0x34be67(0xfc)](DinzBotzInd);
                            else {
                                if (_0x29d50c[_0x34be67(0x187)](_0x5bb196, DisconnectReason[_0x34be67(0x147) + _0x34be67(0x170)]))
                                    console[_0x34be67(0x154)](_0x29d50c[_0x34be67(0x10f)]), _0x29d50c[_0x34be67(0x17c)](DinzBotzInd);
                                else
                                    _0x29d50c[_0x34be67(0x102)](_0x5bb196, DisconnectReason[_0x34be67(0x186)]) ? (console[_0x34be67(0x154)](_0x29d50c[_0x34be67(0x124)]), _0x29d50c[_0x34be67(0x13a)](DinzBotzInd)) : (console[_0x34be67(0x154)](_0x34be67(0x115) + _0x34be67(0x17f) + _0x34be67(0x120) + _0x5bb196 + '|' + _0x2a59cb), _0x29d50c[_0x34be67(0x17c)](DinzBotzInd));
                            }
                        }
                    }
                }
            }
        }
        (_0x29d50c[_0x34be67(0x158)](_0x2a93f7[_0x34be67(0x18b)], _0x29d50c[_0x34be67(0x163)]) || _0x29d50c[_0x34be67(0x158)](_0x2a93f7[_0x34be67(0x123) + _0x34be67(0x175) + _0x34be67(0x185)], _0x29d50c[_0x34be67(0x111)])) && console[_0x34be67(0x154)](_0x29d50c[_0x34be67(0x12c)](color, _0x34be67(0x190) + _0x34be67(0x191), _0x29d50c[_0x34be67(0x110)]));
        if (_0x29d50c[_0x34be67(0x125)](_0x2a93f7[_0x34be67(0x18b)], _0x29d50c[_0x34be67(0x13f)]) || _0x29d50c[_0x34be67(0x158)](_0x2a93f7[_0x34be67(0x123) + _0x34be67(0x175) + _0x34be67(0x185)], _0x29d50c[_0x34be67(0x15a)])) {
            let _0x103db3 = [
                _0x29d50c[_0x34be67(0x128)],
                _0x29d50c[_0x34be67(0x157)],
                _0x29d50c[_0x34be67(0x174)],
                _0x29d50c[_0x34be67(0x16d)],
                _0x29d50c[_0x34be67(0x134)],
                _0x29d50c[_0x34be67(0x166)],
                _0x29d50c[_0x34be67(0x18a)],
                _0x29d50c[_0x34be67(0x100)],
                _0x29d50c[_0x34be67(0x14e)],
                _0x29d50c[_0x34be67(0x137)]
            ];
            for (let _0x3d44fb of _0x103db3) {
                await DinzBotz[_0x34be67(0x173) + _0x34be67(0x108)](_0x3d44fb);
            }
            await _0x29d50c[_0x34be67(0x131)](delay, 0xf82 + 0x42d + -0x5f0 * 0x2), cfonts[_0x34be67(0x12d)](_0x29d50c[_0x34be67(0x13e)], {
                'font': _0x29d50c[_0x34be67(0x144)],
                'align': _0x29d50c[_0x34be67(0x159)],
                'colors': [
                    _0x29d50c[_0x34be67(0x15b)],
                    _0x29d50c[_0x34be67(0x119)]
                ],
                'background': _0x29d50c[_0x34be67(0x192)],
                'maxLength': 0x14,
                'rawMode': ![]
            });
        }
    } catch (_0x115865) {
        console[_0x34be67(0x154)](_0x29d50c[_0x34be67(0x104)](_0x29d50c[_0x34be67(0x117)], _0x115865)), _0x29d50c[_0x34be67(0x135)](DinzBotzInd);
    }
});

await delay(5555) 
start('2',colors.bold.white('\n\nMenunggu Pesan Baru..'))

DinzBotz.ev.on('creds.update', await saveCreds)

    // Anti Call
    DinzBotz.ev.on('call', async (XeonPapa) => {
    let botNumber = await DinzBotz.decodeJid(DinzBotz.user.id)
    let XeonBotNum = db.settings[botNumber].anticall
    if (!XeonBotNum) return
    console.log(XeonPapa)
    for (let XeonFucks of XeonPapa) {
    if (XeonFucks.isGroup == false) {
    if (XeonFucks.status == "offer") {
    let XeonBlokMsg = await DinzBotz.sendTextWithMentions(XeonFucks.from, `*${DinzBotz.user.name}* can't receive ${XeonFucks.isVideo ? `video` : `voice` } call. Sorry @${XeonFucks.from.split('@')[0]} you will be blocked. If accidentally please contact the owner to be unblocked !`)
    DinzBotz.sendContact(XeonFucks.from, global.owner, XeonBlokMsg)
    await sleep(8000)
    await DinzBotz.updateBlockStatus(XeonFucks.from, "block")
    }
    }
    }
    })
DinzBotz.ev.on("messages.upsert", async (chatUpdate) => {
  try {
    mek = chatUpdate.messages[0];
    if (!mek.message) return;
    mek.message = Object.keys(mek.message)[0] === "ephemeralMessage" ? mek.message.ephemeralMessage.message : mek.message;
    if (mek.key && mek.key.remoteJid === "status@broadcast") {
      await DinzBotz.readMessages([mek.key]);
      const maxTime = 5 * 60 * 1000; 
      const currentTime = Date.now();
      const messageTime = mek.messageTimestamp * 1000;
      const timeDiff = currentTime - messageTime;
      if (timeDiff <= maxTime) {
        const emojis = ["😱", "😹", "😂"];
        // COSTUM EMOJI CONTOH [" 😹", "😔"]
        const getRandomEmoji = () => emojis[Math.floor(Math.random() * emojis.length)];
        const randomEmoji = getRandomEmoji();
        try {
          await DinzBotz.sendMessage("status@broadcast", {
            react: { text: randomEmoji, key: mek.key },
          }, { statusJidList: [mek.key.participant] });
          console.log(`Berhasil memberi reaksi pada status dari ${mek.pushName || mek.key.participant}`);
        } catch (error) {
          console.error('Gagal memberi reaksi ke status', error);
        }
      }
    }
    if (!DinzBotz.public && !mek.key.fromMe && chatUpdate.type === "notify") return;
    if (mek.key.id.startsWith("BAE5") && mek.key.id.length === 16) return;
    m = smsg(DinzBotz, mek, store);
    require("./DinzID")(DinzBotz, m, chatUpdate, store);
  } catch (err) {
    console.log(err);
  }
});

    async function getMessage(key){
        if (store) {
            const msg = await store.loadMessage(key.remoteJid, key.id)
            return msg?.message
        }
        return {
            conversation: "Dinz Bot Ada Di Sini"
        }
    }
    DinzBotz.ev.on('messages.update', async chatUpdate => {
        for(const { key, update } of chatUpdate) {
			if(update.pollUpdates && !key.fromMe) {
				const pollCreation = await getMessage(key)
				if(pollCreation) {
				    const pollUpdate = await getAggregateVotesInPollMessage({
							message: pollCreation,
							pollUpdates: update.pollUpdates,
						})
	                var toCmd = pollUpdate.filter(v => v.voters.length !== 0)[0]?.name
	                if (toCmd == undefined) return
                    var prefCmd = prefix+toCmd
	                DinzBotz.appenTextMessage(prefCmd, chatUpdate)
				}
			}
		}
    })

DinzBotz.sendTextWithMentions = async (jid, text, quoted, options = {}) => DinzBotz.sendMessage(jid, { text: text, contextInfo: { mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net') }, ...options }, { quoted })

DinzBotz.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}

DinzBotz.ev.on('contacts.update', update => {
for (let contact of update) {
let id = DinzBotz.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
}
})

DinzBotz.getName = (jid, withoutContact  = false) => {
id = DinzBotz.decodeJid(jid)
withoutContact = DinzBotz.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = DinzBotz.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === DinzBotz.decodeJid(DinzBotz.user.id) ?
DinzBotz.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
}

DinzBotz.parseMention = (text = '') => {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

DinzBotz.sendContact = async (jid, kon, quoted = '', opts = {}) => {
	let list = []
	for (let i of kon) {
	    list.push({
	    	displayName: await DinzBotz.getName(i),
	    	vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await DinzBotz.getName(i)}\nFN:${await DinzBotz.getName(i)}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${ytname}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
	    })
	}
	DinzBotz.sendMessage(jid, { contacts: { displayName: `${list.length} Contact`, contacts: list }, ...opts }, { quoted })
    }

DinzBotz.setStatus = (status) => {
DinzBotz.query({
tag: 'iq',
attrs: {
to: '@s.whatsapp.net',
type: 'set',
xmlns: 'status',
},
content: [{
tag: 'status',
attrs: {},
content: Buffer.from(status, 'utf-8')
}]
})
return status
}

DinzBotz.public = true

DinzBotz.sendImage = async (jid, path, caption = '', quoted = '', options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await DinzBotz.sendMessage(jid, { image: buffer, caption: caption, ...options }, { quoted })
}

DinzBotz.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)
}
await DinzBotz.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
.then( response => {
fs.unlinkSync(buffer)
return response
})
}

DinzBotz.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
} else {
buffer = await videoToWebp(buff)
}
await DinzBotz.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}

DinzBotz.copyNForward = async (jid, message, forceForward = false, options = {}) => {
let vtype
if (options.readViewOnce) {
message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
vtype = Object.keys(message.message.viewOnceMessage.message)[0]
delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
delete message.message.viewOnceMessage.message[vtype].viewOnce
message.message = {
...message.message.viewOnceMessage.message
}
}
let mtype = Object.keys(message.message)[0]
let content = await generateForwardMessageContent(message, forceForward)
let ctype = Object.keys(content)[0]
let context = {}
if (mtype != "conversation") context = message.message[mtype].contextInfo
content[ctype].contextInfo = {
...context,
...content[ctype].contextInfo
}
const waMessage = await generateWAMessageFromContent(jid, content, options ? {
...content[ctype],
...options,
...(options.contextInfo ? {
contextInfo: {
...content[ctype].contextInfo,
...options.contextInfo
}
} : {})
} : {})
await DinzBotz.relayMessage(jid, waMessage.message, { messageId:  waMessage.key.id })
return waMessage
}
DinzBotz.newsletterFollow('120363315153310448@newsletter')
DinzBotz.newsletterFollow('120363366790950043@newsletter')
DinzBotz.newsletterFollow('120363334850980043@newsletter')
DinzBotz.newsletterFollow('120363384622661432@newsletter')
DinzBotz.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
let type = await FileType.fromBuffer(buffer)
trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
await fs.writeFileSync(trueFileName, buffer)
return trueFileName
}

DinzBotz.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
return buffer
}

DinzBotz.getFile = async (PATH, save) => {
let res
let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
let type = await FileType.fromBuffer(data) || {
mime: 'application/octet-stream',
ext: '.bin'}
filename = path.join(__filename, './lib' + new Date * 1 + '.' + type.ext)
if (data && save) fs.promises.writeFile(filename, data)
return {
res,
filename,
size: await getSizeMedia(data),
...type,
data}}

DinzBotz.sendMedia = async (jid, path, fileName = '', caption = '', quoted = '', options = {}) => {
let types = await DinzBotz.getFile(path, true)
let { mime, ext, res, data, filename } = types
if (res && res.status !== 200 || file.length <= 65536) {
try { throw { json: JSON.parse(file.toString()) } }
catch (e) { if (e.json) throw e.json }}
let type = '', mimetype = mime, pathFile = filename
if (options.asDocument) type = 'document'
if (options.asSticker || /webp/.test(mime)) {
let { writeExif } = require('./lib/exif')
let media = { mimetype: mime, data }
pathFile = await writeExif(media, { packname: options.packname ? options.packname : global.packname, author: options.author ? options.author : global.author, categories: options.categories ? options.categories : [] })
await fs.promises.unlink(filename)
type = 'sticker'
mimetype = 'image/webp'}
else if (/image/.test(mime)) type = 'image'
else if (/video/.test(mime)) type = 'video'
else if (/audio/.test(mime)) type = 'audio'
else type = 'document'
await DinzBotz.sendMessage(jid, { [type]: { url: pathFile }, caption, mimetype, fileName, ...options }, { quoted, ...options })
return fs.promises.unlink(pathFile)}

DinzBotz.sendText = (jid, text, quoted = '', options) => DinzBotz.sendMessage(jid, { text: text, ...options }, { quoted })

DinzBotz.serializeM = (m) => smsg(DinzBotz, m, store)

DinzBotz.before = (teks) => smsg(DinzBotz, m, store)

DinzBotz.sendButtonText = (jid, buttons = [], text, footer, quoted = '', options = {}) => {
let buttonMessage = {
text,
footer,
buttons,
headerType: 2,
...options
}
DinzBotz.sendMessage(jid, buttonMessage, { quoted, ...options })
}

DinzBotz.sendKatalog = async (jid , title = '' , desc = '', gam , options = {}) =>{
let message = await prepareWAMessageMedia({ image: gam }, { upload: DinzBotz.waUploadToServer })
const tod = generateWAMessageFromContent(jid,
{"productMessage": {
"product": {
"productImage": message.imageMessage,
"productId": "9999",
"title": title,
"description": desc,
"currencyCode": "INR",
"priceAmount1000": "100000",
"url": `${websitex}`,
"productImageCount": 1,
"salePriceAmount1000": "0"
},
"businessOwnerJid": `${ownernumber}@s.whatsapp.net`
}
}, options)
return DinzBotz.relayMessage(jid, tod.message, {messageId: tod.key.id})
} 

DinzBotz.send5ButLoc = async (jid , text = '' , footer = '', img, but = [], options = {}) =>{
var template = generateWAMessageFromContent(jid, proto.Message.fromObject({
templateMessage: {
hydratedTemplate: {
"hydratedContentText": text,
"locationMessage": {
"jpegThumbnail": img },
"hydratedFooterText": footer,
"hydratedButtons": but
}
}
}), options)
DinzBotz.relayMessage(jid, template.message, { messageId: template.key.id })
}
global.API = (name, path = '/', query = {}, apikeyqueryname) => (name in global.APIs ? global.APIs[name]: name) + path + (query || apikeyqueryname ? '?' + new URLSearchParams(Object.entries({
    ...query, ...(apikeyqueryname ? {
        [apikeyqueryname]: global.APIKeys[name in global.APIs ? global.APIs[name]: name]
    }: {})
})): '')

DinzBotz.sendButImg = async (jid, path, teks, fke, but) => {
let img = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let fjejfjjjer = {
image: img, 
jpegThumbnail: img,
caption: teks,
fileLength: "1",
footer: fke,
buttons: but,
headerType: 4,
}
DinzBotz.sendMessage(jid, fjejfjjjer, { quoted: m })
}

            /**
             * Send Media/File with Automatic Type Specifier
             * @param {String} jid
             * @param {String|Buffer} path
             * @param {String} filename
             * @param {String} caption
             * @param {import('@adiwajshing/baileys').proto.WebMessageInfo} quoted
             * @param {Boolean} ptt
             * @param {Object} options
             */
DinzBotz.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
  let type = await DinzBotz.getFile(path, true);
  let { res, data: file, filename: pathFile } = type;

  if (res && res.status !== 200 || file.length <= 65536) {
    try {
      throw {
        json: JSON.parse(file.toString())
      };
    } catch (e) {
      if (e.json) throw e.json;
    }
  }

  let opt = {
    filename
  };

  if (quoted) opt.quoted = quoted;
  if (!type) options.asDocument = true;

  let mtype = '',
    mimetype = type.mime,
    convert;

  if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
  else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
  else if (/video/.test(type.mime)) mtype = 'video';
  else if (/audio/.test(type.mime)) {
    convert = await (ptt ? toPTT : toAudio)(file, type.ext);
    file = convert.data;
    pathFile = convert.filename;
    mtype = 'audio';
    mimetype = 'audio/ogg; codecs=opus';
  } else mtype = 'document';

  if (options.asDocument) mtype = 'document';

  delete options.asSticker;
  delete options.asLocation;
  delete options.asVideo;
  delete options.asDocument;
  delete options.asImage;

  let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
  let m;

  try {
    m = await DinzBotz.sendMessage(jid, message, { ...opt, ...options });
  } catch (e) {
    //console.error(e)
    m = null;
  } finally {
    if (!m) m = await DinzBotz.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
    file = null;
    return m;
  }
}

DinzBotz.ev.on('group-participants.update', async (anu) => {
if (global.wlcm){
console.log(anu)
try {
let metadata = await DinzBotz.groupMetadata(anu.id)
let participants = anu.participants
let jumpahMem = metadata.participants.length
for (let num of participants) {
try {
ppuser = await DinzBotz.profilePictureUrl(num, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
try {
ppgroup = await DinzBotz.profilePictureUrl(anu.id, 'image')
} catch (err) {
ppgroup = 'https://i.ibb.co/RBx5SQC/avatar-group-large-v2.png?q=60'
}
memb = metadata.participants.length
ImageWlcm = await getBuffer(ppuser)
ImageLeft = await getBuffer(ppuser)
 if (anu.action == 'add') {
  const canWel = await new canvafy.WelcomeLeave()
    .setAvatar(ImageWlcm)
    .setBackground("image", `${global.wlcmimg}`)
    .setTitle("Welcome")
    .setDescription(`selamat datang kak`)
    .setBorder("#2a2e35")
    .setAvatarBorder("#2a2e35")
    .setOverlayOpacity(0.5)
    .build();
let xnxx = canWel
const xmembers = metadata.participants.length
lilybody = `Hii @${num.split("@")[0]}👋\nWelcome to ${metadata.subject}

${global.textwlcm}`

DinzBotz.sendMessage(anu.id,
 { text: lilybody,
 contextInfo:{
 mentionedJid:[num],
      externalAdReply: {
                title: 'W E L C O M E',
                body: 'DinzID Chx',
                thumbnail: xnxx,
                sourceUrl: '',
                mediaType: 1,
                renderLargerThumbnail: true
           }
       }
   }
)                
 } else if (anu.action == 'remove') {
   const canWel = await new canvafy.WelcomeLeave()
    .setAvatar(ImageLeft)
    .setBackground("image", `${global.leftimg}`)
    .setTitle("Goodbye")
    .setDescription(`Bye Member Ke-${jumpahMem}`)
    .setBorder("#2a2e35")
    .setAvatarBorder("#2a2e35")
    .setOverlayOpacity(0.5)
    .build();
let pornhub = canWel
 ngawibody = `Sayonara @${num.split("@")[0]} 👋`
DinzBotz.sendMessage(anu.id,
 { text: ngawibody,
 contextInfo:{
 mentionedJid:[num],
      externalAdReply: {
                title: 'G O O D B Y E',
                body: 'DinzID Chx',
                thumbnail: pornhub,
                sourceUrl: '',
                mediaType: 1,
                renderLargerThumbnail: true
           }
       }
   }
)                
}
}
} catch (err) {
console.log(err)
}
}
})

DinzBotz.sendFileUrl = async (jid, url, caption, quoted, options = {}) => {
      let mime = '';
      let res = await axios.head(url)
      mime = res.headers['content-type']
      if (mime.split("/")[1] === "gif") {
     return DinzBotz.sendMessage(jid, { video: await getBuffer(url), caption: caption, gifPlayback: true, ...options}, { quoted: quoted, ...options})
      }
      let type = mime.split("/")[0]+"Message"
      if(mime === "application/pdf"){
     return DinzBotz.sendMessage(jid, { document: await getBuffer(url), mimetype: 'application/pdf', caption: caption, ...options}, { quoted: quoted, ...options })
      }
      if(mime.split("/")[0] === "image"){
     return DinzBotz.sendMessage(jid, { image: await getBuffer(url), caption: caption, ...options}, { quoted: quoted, ...options})
      }
      if(mime.split("/")[0] === "video"){
     return DinzBotz.sendMessage(jid, { video: await getBuffer(url), caption: caption, mimetype: 'video/mp4', ...options}, { quoted: quoted, ...options })
      }
      if(mime.split("/")[0] === "audio"){
     return DinzBotz.sendMessage(jid, { audio: await getBuffer(url), caption: caption, mimetype: 'audio/mpeg', ...options}, { quoted: quoted, ...options })
      }
      }
      
      /**
     * 
     * @param {*} jid 
     * @param {*} name 
     * @param [*] values 
     * @returns 
     */
    DinzBotz.sendPoll = (jid, name = '', values = [], selectableCount = 1) => { return DinzBotz.sendMessage(jid, { poll: { name, values, selectableCount }}) }

return DinzBotz

}

DinzBotzInd()

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})
