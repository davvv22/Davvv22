//SC BY DINZID VyL
// © BY DinzID Vyl 2022 - 2025
//JANGAN HAPUS CREDITS!! HAPUS? = GW ENC SEMUA!! 

"Yoimiya - MD" /// JANGAN DI UBAH NANTI ERROR
//𝙎𝘾 𝙄𝙉𝙄 𝙁𝙍𝙀𝙀 100% 𝙆𝘼𝙇𝙊 𝘼𝘿𝘼 𝙔𝘼𝙉𝙂 𝙉𝙂𝙀𝙅𝙐𝘼𝙇 𝘽𝙀𝙎𝙊𝙆 𝙈𝘼𝙈𝘼𝙆𝙉𝙔𝘼 𝙈𝘼𝙏𝙄
//𝘼𝘿𝘼 𝙅𝙐𝙂𝘼 𝙔𝘼𝙉𝙂 𝙉𝙊 𝙀𝙉𝘾 100%


𝙏𝙌𝙏𝙊
`𝘿𝙄𝙉𝙕𝙄𝘿 𝐃𝐄𝐕`
`𝙆𝙮𝙖𝙢𝙞 𝙎𝙞𝙡𝙚𝙣𝙘𝙚`
𝙋𝙀𝙉𝙔𝙀𝘿𝙄𝘼 𝘼𝙋𝙄
`𝙎𝙄𝙋𝙐𝙏𝙕`
`𝙎𝙃𝘼𝙉𝙕𝙕`
`𝘾𝙇𝙊𝙐𝘿𝙄𝙈𝘼𝙂𝙀`
𝙏𝙌𝙏𝙊 
𝙁𝙇𝙊𝙒𝙁𝘼𝙇𝘾𝙊𝙉 𝙇𝙀𝘼𝙍𝙄𝙉𝙂 𝘾𝙊𝘿𝙄𝙉𝙂
𝘽𝘼𝙄𝙇𝙀𝙔𝙎
"github:ditss-dev/baileys",

𝐑𝐎𝐎𝐌 𝐂𝐇𝐀𝐓: 'https://chat.whatsapp.com/Gv1gsvCBiukEBpaRQ4qDSO',
𝐂𝐇 𝐎𝐑𝐈 𝐘𝐎𝐈𝐌𝐈𝐘𝐀: 'https://whatsapp.com/channel/0029VazsM78H5JM1Rbn18I0s'
//DILARANG HAPUS CREDITS 
footer '© DinzID VyL | Yoimiya - MD'